public class HelloWorld {
    // This program prints out Hello World to console
	public static void main(String[] args) {
		// main program
		System.out.println("Hello world!");
		Test();

	}
	public static void Test() {
		for (int i=0; i<10; i++){
			System.out.println(i);
		}
	}
}