# Pega

Pega is a Business process management (BPM) tool which was established by pega systems. It is used to create and manage web based applications with less effort.