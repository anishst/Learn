## Free Video Editors

Da Vinci Resolve:
https://www.blackmagicdesign.com/products/davinciresolve

https://www.openshot.org/

http://www.videosoftdev.com/free-video-editor

