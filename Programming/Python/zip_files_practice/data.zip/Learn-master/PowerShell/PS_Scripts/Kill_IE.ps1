﻿Stop-Process -Name 'chrome'
Stop-Process -Name 'iexplore'