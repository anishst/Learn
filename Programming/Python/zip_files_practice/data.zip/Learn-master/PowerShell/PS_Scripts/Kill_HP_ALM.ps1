﻿Stop-Process -Name 'HP-ALM-Explorer.exe'
Stop-Process -Name 'ALM-Client.exe'

Read-Host -Prompt "Script Complete! Press Enter to exit"