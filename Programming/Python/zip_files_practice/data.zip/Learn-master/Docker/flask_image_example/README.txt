1. setup app file
2. create docker file
3. build image using a name: docker build . -t my-flask-image
4. run image: docker run -p 5000:5000 my-flask-image
