# nginx web server

- Download: https://nginx.org/en/download.html
- Guide: https://nginx.org/en/docs/beginners_guide.html
