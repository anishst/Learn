# Windows System Admin

## Package Managers

### Chocolatey
- https://chocolatey.org/docs/installation
- Command Ref: https://chocolatey.org/docs/commands-reference
- https://chocolatey.org/docs/commands-install
- packages available: https://chocolatey.org/packages