import shutil

# get archive format

print(shutil.get_archive_formats())

# dirpath = r'C:\Users\532975\Documents\Automation\GitHub\Learn\Python\misc_practice\Zip_files'
# shutil.make_archive('test_zip', 'zip', base_dir=dirpath)
