#!C:/Python/python
print("Content-type: text/html")
print("")
print("<html><head>")
print("")
print("</head><body>")
print("<h1>Hello from Python.</h1>")
for i in range(0,25):
	print(i)
	print('<br />')
print("</body></html>")