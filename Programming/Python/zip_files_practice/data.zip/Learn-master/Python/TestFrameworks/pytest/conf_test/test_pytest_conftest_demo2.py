import pytest

def test_demo2_methodA(setup, oneTimeSetup):
	print("Running demo2 conftest Method A")

def test_demo2_methodB(setup, oneTimeSetup):
	print("Running demo2 conftest Method B")

