import pytest

def test_methodA(oneTimeSetup, setup):
	print("Running demo1 Method A")

def test_methodB(oneTimeSetup, setup):
	print("Running demo1 Method B")




