# Data Science


## Data Set Sources

- Stack Overflow: https://insights.stackoverflow.com/survey
## plotly
https://plot.ly/python/

```pip install plotly```

### Common Issues
- https://community.plot.ly/t/why-plotlyrequesterror-no-message/8307/8

## Jupyter

- http://jupyter.org/index.html
- https://jupyter.readthedocs.io/en/latest/index.html
- https://www.dataquest.io/blog/jupyter-notebook-tips-tricks-shortcuts/

## Vidoes

- https://www.youtube.com/watch?v=_P7X8tMplsw&t=29s

	

