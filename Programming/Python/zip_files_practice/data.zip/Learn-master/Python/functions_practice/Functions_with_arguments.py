lisitems = [1,2,3,5]

def processList(items):
  for i in items:
    print(i) 


processList(lisitems)

