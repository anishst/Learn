
def processList(*args):
  for i in args:
    print(i) 


processList("test","hellow","wait")

