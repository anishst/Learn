# # Dump the dictionary of fields
# form = cgi.FieldStorage()
# for f in form :
#     print ("Field " + f + " = [" + form[f].value + "]<br>")
