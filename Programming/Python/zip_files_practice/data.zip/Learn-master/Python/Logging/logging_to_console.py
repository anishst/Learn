import logging
logging.basicConfig(level=logging.DEBUG)
logging.debug('This will get logged')
