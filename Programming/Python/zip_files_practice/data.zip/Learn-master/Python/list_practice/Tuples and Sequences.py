# A tuple consists of a number of values separated by commas
# Tuples are immutable: cannot be changed

t = 12345, 54321, 'hello!'
print(t)
print(t[1])

u = t, (1, 2, 3, 4, 5)
print(u)